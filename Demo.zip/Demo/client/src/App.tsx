import './App.css'
import VideoChat from './components/VideoChat'

function App() {

  return (
    <>
     <VideoChat />
    </>
  )
}

export default App
